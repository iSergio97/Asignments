package com.sgd.tap;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TapApplicationTests {

	@Test
	void contextLoads() {
	}

}
