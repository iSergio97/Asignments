package com.sgd.tapbearbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TapBearBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
